define( [
	"./document"
], function( document ) {
	return document.documentElement;
} );
